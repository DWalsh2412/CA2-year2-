﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {   //Creating list
        List<acvititys> acvititys;
        //filtered list for Radio buttons
        List<acvititys> filteredActivitys = new List<acvititys>();
        //defining for add/remove button
        string CurrentItemText;
        int CurrentItemIndex;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            //created 9 Activitys (its spelt wrong i know it was to late when i realised)
            acvititys A1 = new acvititys() { ActityName = "Hicking", Date = new DateTime(01, 07, 2012), ActivityType = "Land" };
            acvititys A2 = new acvititys() { ActityName = "Sailing", Date = new DateTime(01, 07, 2012), ActivityType = "Water"};
            acvititys A3 = new acvititys() { ActityName = "Hand Gliding", Date = new DateTime(01, 07, 2012), ActivityType = "Air" };
            acvititys A4 = new acvititys() { ActityName = "Mountain Biking", Date = new DateTime(02, 07, 2012), ActivityType = "Land" };
            acvititys A5 = new acvititys() { ActityName = "surfing", Date = new DateTime(02, 07, 2012),ActivityType = "Water" };
            acvititys A6 = new acvititys() { ActityName = "Parachuting", Date = new DateTime(02, 07, 2012),ActivityType = "Air" };
            acvititys A7 = new acvititys() { ActityName = "abeiling", Date = new DateTime(03, 07, 2012), ActivityType = "Land" };
            acvititys A8 = new acvititys() { ActityName = "kayaking", Date = new DateTime(03, 07, 2012), ActivityType = "Air"  };
            acvititys A9 = new acvititys() { ActityName = "Helicopter tour", Date = new DateTime(03, 07, 2012), ActivityType = "Air" };
            //Adds Activitys to list
            acvititys = new List<acvititys>();
            acvititys.Add(A1);
            acvititys.Add(A2);
            acvititys.Add(A3);
            acvititys.Add(A4);
            acvititys.Add(A5);
            acvititys.Add(A6);
            acvititys.Add(A7);
            acvititys.Add(A8);
            acvititys.Add(A9);
            //Displays Activitys in Listbox
            Activites.ItemsSource = acvititys;
        }


        private void Activites_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Shows What is Selected
            acvititys selectedActivitys = Activites.SelectedItems as acvititys;
            //Checks if null
            if (selectedActivitys != null)
            {
                TblkDescrption.Text = selectedActivitys.Description();
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //add from one listbox to another
            CurrentItemText = Activites.SelectedValue.ToString();
            CurrentItemIndex = Activites.SelectedIndex;
            ToDoList.Items.Add(CurrentItemText);

            if(acvititys != null)
            {
                acvititys.RemoveAt(CurrentItemIndex);
            }


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // remove from one listbox and add it back
            CurrentItemText = ToDoList.SelectedValue.ToString();
            CurrentItemIndex = ToDoList.SelectedIndex;
            Activites.Items.Add(CurrentItemText);
            ToDoList.Items.RemoveAt(ToDoList.Items.IndexOf(ToDoList.SelectedItems));
            //if you click remove when empty a message will appear
            if (ToDoList == null)
            {
                MessageBox.Show("To Do List is Empty");
            }
        }

        private void rbAll_Checked(object sender, RoutedEventArgs e)
        {
            //resets the filter
            filteredActivitys.Clear();
            //displays all if clicked
            if (rbAll.IsChecked == true)
            {
                Activites.ItemsSource = acvititys;
            }
            //displays land Activitys if clicked
            else if (rbLand.IsChecked == true)
            {
                foreach (acvititys acvititys in acvititys)
                {
                    if (acvititys.ActivityType == "land")
                    {
                        filteredActivitys.Add(acvititys); 
                    }
                }
                Activites.ItemsSource = filteredActivitys;
            }
            //displays Water Activitys if clicked
            else if (rbWater.IsChecked == true)
            {
                foreach (acvititys acvititys in acvititys)
                {
                    if (acvititys.ActivityType == "Water")
                    {
                        filteredActivitys.Add(acvititys);
                    }
                }
                Activites.ItemsSource = filteredActivitys;
            }
            //displays Air Activitys if clicked
            else if (rbAir.IsChecked == true)
            {
                foreach (acvititys acvititys in acvititys)
                {
                    if (acvititys.ActivityType == "Air")
                    {
                        filteredActivitys.Add(acvititys);
                    }
                }
                Activites.ItemsSource = filteredActivitys;
            }
        }

        
    }
}
